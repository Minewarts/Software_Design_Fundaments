"""Acceso mínimo a PostgreSQL (Supabase) con psycopg 3."""
import psycopg
from psycopg.rows import dict_row

from app.infrastructure.config.settings import settings


def conexion() -> psycopg.Connection:
    # prepare_threshold=None: compatible con el pooler de Supabase (modo transacción).
    # `with conexion() as con:` hace commit al salir y rollback ante excepción.
    return psycopg.connect(settings.database_url, row_factory=dict_row, prepare_threshold=None)


def q(sql: str, params=None, uno: bool = False):
    with conexion() as con:
        cur = con.execute(sql, params)
        rows = cur.fetchall() if cur.description else None
    return (rows[0] if rows else None) if uno else rows
