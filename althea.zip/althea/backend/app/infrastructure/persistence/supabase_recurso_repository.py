"""Repositorio de recursos del catálogo + administración CRUD (HU-01..05)."""
from __future__ import annotations

from dataclasses import fields
from decimal import Decimal
from uuid import UUID

from app.application.ports.recurso_repository import RecursoRepository
from app.domain.entities.recursos import Actividad, Alojamiento, Destino, Transporte
from app.domain.exceptions.errores import DominioError
from app.infrastructure.persistence.db import conexion, q

_TABLA = {Destino: "destino", Alojamiento: "alojamiento", Actividad: "actividad", Transporte: "transporte"}
_cols = lambda cls: ", ".join(f.name for f in fields(cls))  # noqa: E731


class SupabaseRecursoRepository(RecursoRepository):
    def guardar(self, r):
        cols = [f.name for f in fields(r)]
        q(f"INSERT INTO {_TABLA[type(r)]} ({', '.join(cols)}) VALUES ({', '.join(['%s'] * len(cols))})",
          [getattr(r, c) for c in cols])
        return r

    def buscar_destinos(self, id_destino: UUID | None = None):
        rows = q(f"SELECT {_cols(Destino)} FROM destino WHERE (%s::uuid IS NULL OR id = %s::uuid)",
                 (id_destino, id_destino))
        return [Destino(**r) for r in rows]

    def buscar_alojamientos(self, id_destino, tarifa_max_noche: Decimal):
        rows = q(f"SELECT {_cols(Alojamiento)} FROM alojamiento "
                 "WHERE (%s::uuid IS NULL OR id_destino = %s::uuid) AND tarifa_noche <= %s",
                 (id_destino, id_destino, tarifa_max_noche))
        return [Alojamiento(**r) for r in rows]

    def buscar_actividades(self, id_destino, costo_max_persona: Decimal, tipos: tuple = ()):
        pats = [f"%{t}%" for t in tipos]

        def consulta(filtrar: bool):
            sql = (f"SELECT {_cols(Actividad)} FROM actividad "
                   "WHERE (%s::uuid IS NULL OR id_destino = %s::uuid) AND costo_persona <= %s")
            params = [id_destino, id_destino, costo_max_persona]
            if filtrar:
                sql += " AND (tipo_actividad ILIKE ANY(%s) OR nombre ILIKE ANY(%s))"
                params += [pats, pats]
            return q(sql, params)

        rows = (consulta(True) if pats else None) or consulta(False)  # sin coincidencias de intereses → sin filtro
        return [Actividad(**r) for r in rows]

    def buscar_transportes(self, tarifa_max: Decimal):
        rows = q(f"SELECT {_cols(Transporte)} FROM transporte WHERE tarifa_estimada <= %s", (tarifa_max,))
        return [Transporte(**r) for r in rows]


TABLAS = {
    "destinos": ("destino", ["nombre", "ubicacion", "clima_promedio"]),
    "alojamientos": ("alojamiento", ["id_destino", "nombre", "categoria_estrellas", "tarifa_noche"]),
    "actividades": ("actividad", ["id_destino", "nombre", "tipo_actividad", "costo_persona"]),
    "transportes": ("transporte", ["tipo_vehiculo", "tarifa_estimada"]),
}


def _cfg(tipo: str):
    if tipo not in TABLAS:
        raise DominioError(f"Tipo de recurso desconocido: {tipo}")
    return TABLAS[tipo]


class CatalogoAdmin:
    """Listado, edición, borrado y relaciones del catálogo (consultas para la UI)."""

    def listar(self, tipo: str):
        tabla, _ = _cfg(tipo)
        if tipo == "transportes":
            return q("SELECT t.*, COALESCE(array_agg(dt.id_destino) FILTER (WHERE dt.id_destino IS NOT NULL), '{}') "
                     "AS ids_destinos FROM transporte t LEFT JOIN destino_transporte dt ON dt.id_transporte = t.id "
                     "GROUP BY t.id ORDER BY t.tipo_vehiculo")
        return q(f"SELECT * FROM {tabla} ORDER BY nombre")

    def actualizar(self, tipo: str, id_: UUID, datos: dict):
        tabla, cols = _cfg(tipo)
        sets = {c: datos[c] for c in cols if c in datos}
        if sets:
            q(f"UPDATE {tabla} SET {', '.join(f'{c} = %s' for c in sets)} WHERE id = %s", (*sets.values(), id_))
        if tipo == "transportes" and "ids_destinos" in datos:
            self.sincronizar_destinos(id_, datos["ids_destinos"])

    def eliminar(self, tipo: str, id_: UUID):
        tabla, _ = _cfg(tipo)
        q(f"DELETE FROM {tabla} WHERE id = %s", (id_,))

    def sincronizar_destinos(self, id_transporte, ids_destinos):
        with conexion() as con:
            con.execute("DELETE FROM destino_transporte WHERE id_transporte = %s", (id_transporte,))
            for d in ids_destinos or []:
                con.execute("INSERT INTO destino_transporte (id_destino, id_transporte) VALUES (%s, %s)",
                            (d, id_transporte))

    def relaciones(self):
        return q("""
          SELECT d.id, d.nombre AS destino,
            COALESCE((SELECT json_agg(json_build_object('nombre', a.nombre)) FROM alojamiento a WHERE a.id_destino = d.id), '[]') AS alojamientos,
            COALESCE((SELECT json_agg(json_build_object('nombre', c.nombre)) FROM actividad c WHERE c.id_destino = d.id), '[]') AS actividades,
            COALESCE((SELECT json_agg(json_build_object('nombre', t.tipo_vehiculo)) FROM transporte t
                      JOIN destino_transporte dt ON dt.id_transporte = t.id WHERE dt.id_destino = d.id), '[]') AS transportes
          FROM destino d ORDER BY d.nombre""")
