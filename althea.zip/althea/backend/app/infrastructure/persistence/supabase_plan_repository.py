"""Repositorio de planes, itinerario, valoraciones y notificaciones."""
from __future__ import annotations

from uuid import UUID, uuid4

from app.application.ports.plan_repository import PlanRepository
from app.domain.entities.enums import EstadoPlan, TipoRecurso
from app.domain.entities.plan_turistico import ItemItinerario, PlanTuristico
from app.infrastructure.persistence.db import conexion, q

_COL = {TipoRecurso.ALOJAMIENTO: "id_alojamiento", TipoRecurso.ACTIVIDAD: "id_actividad",
        TipoRecurso.TRANSPORTE: "id_transporte"}
_INS_ITEM = ("INSERT INTO item_itinerario (id, id_plan, numero_dia, orden, tipo_recurso, {col}) "
             "VALUES (%s, %s, %s, %s, %s::tipo_recurso, %s)")
_DESTINO = ("SELECT {campo} FROM item_itinerario i LEFT JOIN alojamiento a ON a.id = i.id_alojamiento "
            "LEFT JOIN actividad ac ON ac.id = i.id_actividad JOIN destino d ON d.id = COALESCE(a.id_destino, ac.id_destino) "
            "WHERE i.id_plan = p.id LIMIT 1")
_BASE = f"""
  SELECT p.id, p.titulo, p.estado::text AS estado, p.costo_estimado, p.cantidad_viajeros,
    (SELECT MAX(numero_dia) FROM item_itinerario WHERE id_plan = p.id) AS duracion,
    ({_DESTINO.format(campo='d.id')}) AS id_destino,
    ({_DESTINO.format(campo='d.nombre')}) AS destino,
    (SELECT ROUND(AVG(puntuacion), 1) FROM valoracion WHERE id_plan = p.id) AS calificacion
  FROM plan_turistico p"""
_ITEMS = """
  SELECT i.id, i.numero_dia, i.orden, i.tipo_recurso::text AS tipo_recurso, i.id_recurso_asociado AS id_recurso,
         COALESCE(a.nombre, ac.nombre, t.tipo_vehiculo) AS nombre
  FROM item_itinerario i LEFT JOIN alojamiento a ON a.id = i.id_alojamiento
  LEFT JOIN actividad ac ON ac.id = i.id_actividad LEFT JOIN transporte t ON t.id = i.id_transporte
  WHERE i.id_plan = %s ORDER BY i.numero_dia, i.orden"""
_LISTAR = f"""SELECT * FROM ({_BASE}) t
  WHERE (%(estado)s::text IS NULL OR estado = %(estado)s::text)
    AND (%(destino)s::text IS NULL OR destino ILIKE %(destino)s::text)
    AND (%(pmin)s::numeric IS NULL OR costo_estimado >= %(pmin)s::numeric)
    AND (%(pmax)s::numeric IS NULL OR costo_estimado <= %(pmax)s::numeric)
    AND (%(dias)s::int IS NULL OR duracion <= %(dias)s::int)
  ORDER BY titulo"""
# Costo = Σ hoteles distintos × noches × habitaciones + Σ actividades × viajeros + Σ transportes
_COSTO = """
  WITH it AS (SELECT * FROM item_itinerario WHERE id_plan = %(p)s),
       v  AS (SELECT cantidad_viajeros AS n FROM plan_turistico WHERE id = %(p)s),
       nc AS (SELECT GREATEST(COALESCE(MAX(numero_dia), 1) - 1, 1) AS noches FROM it)
  UPDATE plan_turistico SET costo_estimado =
      COALESCE((SELECT SUM(a.tarifa_noche) FROM alojamiento a
                WHERE a.id IN (SELECT id_alojamiento FROM it WHERE id_alojamiento IS NOT NULL)), 0)
        * (SELECT noches FROM nc) * CEIL((SELECT n FROM v) / 2.0)
    + COALESCE((SELECT SUM(ac.costo_persona) FROM it JOIN actividad ac ON ac.id = it.id_actividad), 0) * (SELECT n FROM v)
    + COALESCE((SELECT SUM(t.tarifa_estimada) FROM it JOIN transporte t ON t.id = it.id_transporte), 0)
  WHERE id = %(p)s"""


class SupabasePlanRepository(PlanRepository):
    def guardar(self, plan: PlanTuristico) -> PlanTuristico:
        with conexion() as con:
            con.execute("INSERT INTO plan_turistico (id, titulo, estado, costo_estimado, cantidad_viajeros) "
                        "VALUES (%s, %s, %s::estado_plan, %s, %s)",
                        (plan.id, plan.titulo, plan.estado.value, plan.costo_estimado, plan.cantidad_viajeros))
            for i in plan.items:
                t = TipoRecurso(i.tipo_recurso)
                con.execute(_INS_ITEM.format(col=_COL[t]),
                            (i.id, i.id_plan, i.numero_dia, i.orden, t.value, i.id_recurso_asociado))
        return plan

    def obtener_por_id(self, id_plan: UUID):
        r = q("SELECT id, titulo, estado::text AS estado, costo_estimado, cantidad_viajeros "
              "FROM plan_turistico WHERE id = %s", (id_plan,), uno=True)
        if not r:
            return None
        plan = PlanTuristico(titulo=r["titulo"], estado=EstadoPlan(r["estado"]), costo_estimado=r["costo_estimado"],
                             cantidad_viajeros=r["cantidad_viajeros"], id=r["id"])
        for i in q(_ITEMS, (id_plan,)):
            plan.items.append(ItemItinerario(id_plan=plan.id, numero_dia=i["numero_dia"], orden=i["orden"],
                                             id_recurso_asociado=i["id_recurso"],
                                             tipo_recurso=TipoRecurso(i["tipo_recurso"]), id=i["id"]))
        return plan

    def ficha(self, id_plan: UUID):
        f = q(f"SELECT * FROM ({_BASE}) t WHERE id = %s", (id_plan,), uno=True)
        if f:
            f["items"] = q(_ITEMS, (id_plan,))
        return f

    def listar(self, filtros: dict):
        d = filtros.get("destino")
        return q(_LISTAR, {"estado": filtros.get("estado") or None, "destino": f"%{d}%" if d else None,
                           "pmin": filtros.get("precio_min"), "pmax": filtros.get("precio_max"),
                           "dias": filtros.get("dias_max")})

    def duplicar(self, id_plan: UUID) -> UUID:
        with conexion() as con:
            nuevo = con.execute(
                "INSERT INTO plan_turistico (titulo, estado, costo_estimado, cantidad_viajeros) "
                "SELECT 'Copia de ' || titulo, 'BORRADOR', costo_estimado, cantidad_viajeros "
                "FROM plan_turistico WHERE id = %s RETURNING id", (id_plan,)).fetchone()["id"]
            con.execute("INSERT INTO item_itinerario (id_plan, numero_dia, orden, tipo_recurso, id_alojamiento, "
                        "id_actividad, id_transporte) SELECT %s, numero_dia, orden, tipo_recurso, id_alojamiento, "
                        "id_actividad, id_transporte FROM item_itinerario WHERE id_plan = %s", (nuevo, id_plan))
        return nuevo

    def _siguiente_orden(self, con, id_plan, dia) -> int:
        return con.execute("SELECT COALESCE(MAX(orden), 0) + 1 AS o FROM item_itinerario "
                           "WHERE id_plan = %s AND numero_dia = %s", (id_plan, dia)).fetchone()["o"]

    def agregar_item(self, id_plan, numero_dia, tipo, id_recurso):
        t = TipoRecurso(tipo)
        with conexion() as con:
            o = self._siguiente_orden(con, id_plan, numero_dia)
            con.execute(_INS_ITEM.format(col=_COL[t]), (uuid4(), id_plan, numero_dia, o, t.value, id_recurso))

    def quitar_item(self, id_plan, id_item):
        q("DELETE FROM item_itinerario WHERE id = %s AND id_plan = %s", (id_item, id_plan))

    def mover_item(self, id_plan, id_item, numero_dia):
        with conexion() as con:
            o = self._siguiente_orden(con, id_plan, numero_dia)
            con.execute("UPDATE item_itinerario SET numero_dia = %s, orden = %s WHERE id = %s AND id_plan = %s",
                        (numero_dia, o, id_item, id_plan))

    def cambiar_estado(self, id_plan, estado):
        q("UPDATE plan_turistico SET estado = %s::estado_plan WHERE id = %s", (EstadoPlan(estado).value, id_plan))

    def recalcular_costo(self, id_plan):
        q(_COSTO, {"p": id_plan})

    def valoraciones(self, id_plan):
        return q("SELECT id, autor, puntuacion, comentario, created_at FROM valoracion "
                 "WHERE id_plan = %s ORDER BY created_at DESC", (id_plan,))

    def calificar(self, id_plan, autor, puntuacion, comentario):
        q("INSERT INTO valoracion (id_plan, autor, puntuacion, comentario) VALUES (%s, %s, %s, %s)",
          (id_plan, autor, puntuacion, comentario))

    def notificar(self, id_plan, mensaje):
        q("INSERT INTO notificacion (id_plan, mensaje) VALUES (%s, %s)", (id_plan, mensaje))

    def notificaciones(self):
        return q("SELECT n.id, n.id_plan, p.titulo, n.mensaje, n.leida, n.created_at FROM notificacion n "
                 "JOIN plan_turistico p ON p.id = n.id_plan ORDER BY n.created_at DESC LIMIT 30")

    def marcar_leidas(self):
        q("UPDATE notificacion SET leida = true WHERE NOT leida")
