# Althea – Planes Turísticos
## Backend (FastAPI)
1. `cd backend && python -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt`
2. `cp .env.example .env` y completa `DATABASE_URL` y `ANTHROPIC_API_KEY`.
3. En Supabase (SQL Editor) ejecuta en orden: `sql/001_schema_turismo.sql`, `002_release1_extras.sql`, `003_release2.sql`.
4. `uvicorn app.main:app --reload`  → http://localhost:8000/docs
## Frontend (Vue 3 + Vite)
`cd frontend && npm install && npm run dev`  → http://localhost:5173
## Tests
`cd backend && pip install pytest && PYTHONPATH=. pytest tests/unit`
